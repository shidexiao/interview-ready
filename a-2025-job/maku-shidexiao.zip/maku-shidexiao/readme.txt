
作者：石德晓

做了1、3、4、5四道题
分别对应
q1_fizzbuzz.py
q3-glided-rose-python
q4_todo_list
q5_mnist.ipynb




