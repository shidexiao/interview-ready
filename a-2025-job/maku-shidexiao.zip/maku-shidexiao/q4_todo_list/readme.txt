

初始化数据库：
flask shell
>>> db.create_all()

启动服务：
flask run --debug

访问浏览器
127.0.0.1:5000
