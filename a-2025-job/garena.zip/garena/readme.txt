(ml3118) de@dembp garena % pytest test_num_to_str.py
==================================================================== test session starts =====================================================================
platform darwin -- Python 3.11.8, pytest-8.4.1, pluggy-1.6.0
rootdir: /Users/de/garena
plugins: anyio-4.4.0
collected 6 items

test_num_to_str.py ......                                                                                                                              [100%]

===================================================================== 6 passed in 0.02s ======================================================================
(ml3118) de@dembp garena % mypy num_to_str.py test_num_to_str.py
Success: no issues found in 2 source files
(ml3118) de@dembp garena %
